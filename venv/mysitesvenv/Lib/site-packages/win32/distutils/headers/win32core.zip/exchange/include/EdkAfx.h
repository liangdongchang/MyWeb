// edkafx.h : #include file for standard EDK system include files,
//            These are used frequently, but are changed infrequently
// Copyright 1986 - 1999 Microsoft Corporation.  All Rights Reserved.

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

#define _INC_WINDOWSX       // This keeps "WindowsX.h" from being included.
#define _MAPINLS_H_         // This keeps "MAPInls.h" from being included.
#include <edk.h>
